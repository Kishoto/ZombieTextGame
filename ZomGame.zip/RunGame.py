from ZombieGame import Zombies

def main():
    Zombies()

main()
